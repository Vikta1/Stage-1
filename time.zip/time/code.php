
<?php
date_default_timezone_set('Africa/Lagos');
$current_time=date('h:i:s a');

echo $current_time
?>

<div class="first" style="margin-top: 150px;">

   <section class="header" style="background-size: cover">
       <header class=" container text-center">
           <h1 style="color: #31b0d5"> LASACO Assurance PLC </h1>
           <p> Amplify Digital is a full service digital marketing and digital product.</p>
       </header>

       <div class="header-image img-responsive">
           <img src="images/header_image.png" alt="tommorow's future leader" />
       </div>
   </section>




